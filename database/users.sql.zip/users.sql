-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2021 at 02:20 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--
CREATE DATABASE IF NOT EXISTS `users` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `users`;

-- --------------------------------------------------------

--
-- Table structure for table `usersinfo`
--

CREATE TABLE `usersinfo` (
  `id` int(11) NOT NULL,
  `nameUser` varchar(512) NOT NULL,
  `email` varchar(320) NOT NULL,
  `password` varchar(512) NOT NULL,
  `developerType` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usersinfo`
--

INSERT INTO `usersinfo` (`id`, `nameUser`, `email`, `password`, `developerType`) VALUES
(4, 'Admin Adminovski', 'asdf@wow.com', '$2y$10$nq.RZk2PlqQBbYT6VzCFk.X68fl1zvtYNogEyYtztseuxRRyGI0ny', 2),
(19, 'Ognen Anastasov', 'ognen_a@hotmail.com', '$2y$10$X4jfJn/m0sF/a6eOzo8Li.VnsKbGQFq5BhGaHf/WQErOFUU.EjBgG', 1),
(27, 'Damjan Damjanoski', '123@mail.com', '$2y$10$mxcVuLie/k06MU5lQhhAsekErGpoNf./yOy3j7oWiUeQQ3gryGN9K', 2111),
(29, 'Ognen Ognenovski', 'ugab@mail.com', '$2y$10$RTdkwghXcuq0g9qFSidsfOunh3f4Q9943gQDvrAMFQYupTUNj99Y.', 13),
(31, 'Asd Asdovski', '1@mail.com', '$2y$10$J6hjiyIcL0TJCEQ3ytgbseVg3CXjgdn7iJDGQY4J5QH4r7yWw5dd.', 111),
(33, 'Mihail Mihajlovski', '2@mail.com', '$2y$10$/sQHDyJVtUcZLAcuQ1CeOefQcatJ3reXrL3g9l7Cc/t9hwX6HDaQ6', 12),
(35, 'Damjan Damjanoski Sr.', '3@mail.com', '$2y$10$QDNdty2y8tNgo4NYpF4.He2rVrlo6mnL5FTaZ9qnqhUIvtDAT6uUS', 13),
(37, 'Test Ime', '5@mail.com', '$2y$10$nfhbXXkb7DxF8oMRVhrqCu6aRjgbd7PHrPWjdMWRfEJsLFEzjvUBe', 22),
(39, 'Teo Teodorovski', '321@mail.com', '$2y$10$a0fyM6aR9/An9cQ11a2D8O1e.34HY7E9KkpTGr0SABdgWNV83pNeO', 1),
(40, 'Teodora Teodorovski', '22@mail.com', '$2y$10$hNsfqJeq9ZUXhwPb2QN14e8XSTCRecYWCn2vlGPWNnJ3k2oZ1rtnC', 21),
(41, 'Fifthy Cent', 'fifthy@kozle.com', '$2y$10$xVk.YJYxn.DHmJ6LhCiR8eqbZcZ4h5FzbWJRjP8GDrr7X3.y900b.', 221),
(42, 'Test Testovski', 'test@mail.com', '$2y$10$/SMovWmoPhGZGpAjLKYlhuvaN/uxwg19RI9xmPqkIxeux1oPpp23C', 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usersinfo`
--
ALTER TABLE `usersinfo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usersinfo`
--
ALTER TABLE `usersinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
